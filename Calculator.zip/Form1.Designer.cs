﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.seven = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.mult = new System.Windows.Forms.Button();
            this.divi = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.plusminus = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.subtract = new System.Windows.Forms.Button();
            this.decpoint = new System.Windows.Forms.Button();
            this.equals = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.minusplus = new System.Windows.Forms.Button();
            this.sqrt = new System.Windows.Forms.Button();
            this.squared = new System.Windows.Forms.Button();
            this.tan = new System.Windows.Forms.Button();
            this.cos = new System.Windows.Forms.Button();
            this.sin = new System.Windows.Forms.Button();
            this.pi = new System.Windows.Forms.Button();
            this.exp = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(22, 156);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(75, 23);
            this.seven.TabIndex = 0;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.button1_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(103, 156);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(75, 23);
            this.eight.TabIndex = 1;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(184, 156);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(75, 23);
            this.nine.TabIndex = 2;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(22, 185);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(75, 23);
            this.four.TabIndex = 3;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(103, 185);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(75, 23);
            this.five.TabIndex = 4;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(184, 185);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(75, 23);
            this.six.TabIndex = 5;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(22, 214);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(75, 23);
            this.one.TabIndex = 6;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(103, 214);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(75, 23);
            this.two.TabIndex = 7;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(184, 214);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(75, 23);
            this.three.TabIndex = 8;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // mult
            // 
            this.mult.Location = new System.Drawing.Point(278, 156);
            this.mult.Name = "mult";
            this.mult.Size = new System.Drawing.Size(75, 23);
            this.mult.TabIndex = 9;
            this.mult.Text = "*";
            this.mult.UseVisualStyleBackColor = true;
            this.mult.Click += new System.EventHandler(this.mult_Click);
            // 
            // divi
            // 
            this.divi.Location = new System.Drawing.Point(278, 185);
            this.divi.Name = "divi";
            this.divi.Size = new System.Drawing.Size(75, 23);
            this.divi.TabIndex = 10;
            this.divi.Text = "/";
            this.divi.UseVisualStyleBackColor = true;
            this.divi.Click += new System.EventHandler(this.divi_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(278, 214);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(75, 23);
            this.plus.TabIndex = 11;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // plusminus
            // 
            this.plusminus.Location = new System.Drawing.Point(22, 243);
            this.plusminus.Name = "plusminus";
            this.plusminus.Size = new System.Drawing.Size(75, 23);
            this.plusminus.TabIndex = 12;
            this.plusminus.Text = "C";
            this.plusminus.UseVisualStyleBackColor = true;
            this.plusminus.Click += new System.EventHandler(this.clear_Click);
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(103, 243);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(75, 23);
            this.zero.TabIndex = 13;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // subtract
            // 
            this.subtract.Location = new System.Drawing.Point(278, 243);
            this.subtract.Name = "subtract";
            this.subtract.Size = new System.Drawing.Size(75, 23);
            this.subtract.TabIndex = 14;
            this.subtract.Text = "-";
            this.subtract.UseVisualStyleBackColor = true;
            this.subtract.Click += new System.EventHandler(this.subtract_Click);
            // 
            // decpoint
            // 
            this.decpoint.Location = new System.Drawing.Point(184, 243);
            this.decpoint.Name = "decpoint";
            this.decpoint.Size = new System.Drawing.Size(75, 23);
            this.decpoint.TabIndex = 15;
            this.decpoint.Text = ".";
            this.decpoint.UseVisualStyleBackColor = true;
            this.decpoint.Click += new System.EventHandler(this.decpoint_Click);
            // 
            // equals
            // 
            this.equals.Location = new System.Drawing.Point(22, 272);
            this.equals.Name = "equals";
            this.equals.Size = new System.Drawing.Size(237, 23);
            this.equals.TabIndex = 16;
            this.equals.Text = "=";
            this.equals.UseVisualStyleBackColor = true;
            this.equals.Click += new System.EventHandler(this.equals_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(22, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(331, 22);
            this.textBox1.TabIndex = 17;
            // 
            // minusplus
            // 
            this.minusplus.Location = new System.Drawing.Point(184, 64);
            this.minusplus.Name = "minusplus";
            this.minusplus.Size = new System.Drawing.Size(75, 23);
            this.minusplus.TabIndex = 18;
            this.minusplus.Text = "Ans";
            this.minusplus.UseVisualStyleBackColor = true;
            this.minusplus.Click += new System.EventHandler(this.minusplus_Click);
            // 
            // sqrt
            // 
            this.sqrt.Location = new System.Drawing.Point(103, 64);
            this.sqrt.Name = "sqrt";
            this.sqrt.Size = new System.Drawing.Size(75, 23);
            this.sqrt.TabIndex = 19;
            this.sqrt.Text = "sqrt";
            this.sqrt.UseVisualStyleBackColor = true;
            this.sqrt.Click += new System.EventHandler(this.sqrt_Click);
            // 
            // squared
            // 
            this.squared.Location = new System.Drawing.Point(22, 64);
            this.squared.Name = "squared";
            this.squared.Size = new System.Drawing.Size(75, 23);
            this.squared.TabIndex = 20;
            this.squared.Text = "x^2";
            this.squared.UseVisualStyleBackColor = true;
            this.squared.Click += new System.EventHandler(this.squared_Click);
            // 
            // tan
            // 
            this.tan.Location = new System.Drawing.Point(184, 93);
            this.tan.Name = "tan";
            this.tan.Size = new System.Drawing.Size(75, 23);
            this.tan.TabIndex = 21;
            this.tan.Text = "tan";
            this.tan.UseVisualStyleBackColor = true;
            this.tan.Click += new System.EventHandler(this.tan_Click);
            // 
            // cos
            // 
            this.cos.Location = new System.Drawing.Point(103, 93);
            this.cos.Name = "cos";
            this.cos.Size = new System.Drawing.Size(75, 23);
            this.cos.TabIndex = 22;
            this.cos.Text = "cos";
            this.cos.UseVisualStyleBackColor = true;
            this.cos.Click += new System.EventHandler(this.cos_Click);
            // 
            // sin
            // 
            this.sin.Location = new System.Drawing.Point(22, 93);
            this.sin.Name = "sin";
            this.sin.Size = new System.Drawing.Size(75, 23);
            this.sin.TabIndex = 23;
            this.sin.Text = "sin";
            this.sin.UseVisualStyleBackColor = true;
            this.sin.Click += new System.EventHandler(this.sin_Click);
            // 
            // pi
            // 
            this.pi.Location = new System.Drawing.Point(184, 122);
            this.pi.Name = "pi";
            this.pi.Size = new System.Drawing.Size(75, 23);
            this.pi.TabIndex = 24;
            this.pi.Text = "pi";
            this.pi.UseVisualStyleBackColor = true;
            this.pi.Click += new System.EventHandler(this.pi_Click);
            // 
            // exp
            // 
            this.exp.Location = new System.Drawing.Point(103, 122);
            this.exp.Name = "exp";
            this.exp.Size = new System.Drawing.Size(75, 23);
            this.exp.TabIndex = 25;
            this.exp.Text = "exp";
            this.exp.UseVisualStyleBackColor = true;
            this.exp.Click += new System.EventHandler(this.exp_Click);
            // 
            // log
            // 
            this.log.Location = new System.Drawing.Point(22, 122);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(75, 23);
            this.log.TabIndex = 26;
            this.log.Text = "log";
            this.log.UseVisualStyleBackColor = true;
            this.log.Click += new System.EventHandler(this.log_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 308);
            this.Controls.Add(this.log);
            this.Controls.Add(this.exp);
            this.Controls.Add(this.pi);
            this.Controls.Add(this.sin);
            this.Controls.Add(this.cos);
            this.Controls.Add(this.tan);
            this.Controls.Add(this.squared);
            this.Controls.Add(this.sqrt);
            this.Controls.Add(this.minusplus);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.equals);
            this.Controls.Add(this.decpoint);
            this.Controls.Add(this.subtract);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.plusminus);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.divi);
            this.Controls.Add(this.mult);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button mult;
        private System.Windows.Forms.Button divi;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button plusminus;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button subtract;
        private System.Windows.Forms.Button decpoint;
        private System.Windows.Forms.Button equals;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button minusplus;
        private System.Windows.Forms.Button sqrt;
        private System.Windows.Forms.Button squared;
        private System.Windows.Forms.Button tan;
        private System.Windows.Forms.Button cos;
        private System.Windows.Forms.Button sin;
        private System.Windows.Forms.Button pi;
        private System.Windows.Forms.Button exp;
        private System.Windows.Forms.Button log;
    }
}

